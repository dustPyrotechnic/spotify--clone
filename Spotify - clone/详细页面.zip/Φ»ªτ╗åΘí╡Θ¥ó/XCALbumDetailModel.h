//
//  XCALbumDetailModel.h
//  Spotify - clone
//
//  Created by 红尘一笑 on 2025/12/9.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface XCALbumDetailModel : NSObject

@end

NS_ASSUME_NONNULL_END
