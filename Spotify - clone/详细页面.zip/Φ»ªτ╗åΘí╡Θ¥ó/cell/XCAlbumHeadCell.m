//
//  XCAlbumHeadCell.m
//  Spotify - clone
//
//  Created by 红尘一笑 on 2025/12/21.
//

#import "XCAlbumHeadCell.h"

@implementation XCAlbumHeadCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
