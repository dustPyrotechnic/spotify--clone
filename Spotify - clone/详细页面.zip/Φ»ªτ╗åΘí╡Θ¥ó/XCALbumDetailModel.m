//
//  XCALbumDetailModel.m
//  Spotify - clone
//
//  Created by 红尘一笑 on 2025/12/9.
//

#import "XCALbumDetailModel.h"

@implementation XCALbumDetailModel

@end
